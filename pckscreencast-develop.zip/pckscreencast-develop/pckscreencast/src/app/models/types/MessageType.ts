export type MessageType =
  | "SessionDescription"
  | "IceCandidate"
  | "UserJoined"
  | "UserLeft"
  | "Ping";
