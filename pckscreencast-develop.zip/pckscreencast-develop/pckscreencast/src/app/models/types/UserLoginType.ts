export type UserLoginType = "MODERATOR" | "CLIENT" | "OBSERVER";
