export type StreamType = "video" | "screenshare";
