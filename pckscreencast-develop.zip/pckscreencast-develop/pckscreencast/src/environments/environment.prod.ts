export const environment = {
  production: true,
  //webSocketUrl: "wss://pckscreencast.herokuapp.com",
  webSocketUrl: "wss://innotest.space:1234",
};
