export class ErrorHandlerService {
  constructor() {}
}
