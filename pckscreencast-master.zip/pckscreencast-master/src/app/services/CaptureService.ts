import { Injectable } from "@angular/core";
import { ErrorHandlerService } from "./ErrorHandlerService";

@Injectable()
export class CaptureService {
  constructor(private readonly errorHandlerService: ErrorHandlerService) {}

  async startCapture(displayMediaOptions): Promise<void> {
    let captureStream;
    try {
      const mediaDevices = navigator.mediaDevices as any;
      captureStream = await mediaDevices.getDisplayMedia(displayMediaOptions);
    } catch (err) {}
    return captureStream;
  }
}
